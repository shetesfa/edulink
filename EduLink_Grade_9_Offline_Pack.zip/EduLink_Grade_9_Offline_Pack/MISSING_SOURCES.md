# Grade 9 Offline Study Pack — Source Tracking & Transparency

## Included Subjects (100% Grounded in `textbooks.db`):
1. **Mathematics** (Units 1-9, Pages 12-375) — *Units 1 & 2 preserved from Gold Standard*
2. **Biology** (Units 1-6, Pages 6-171)
3. **Chemistry** (Units 1-4, Pages 6-183)
4. **Economics** (Units 1-8, Pages 6-119)
5. **English** (Units 1-6, Pages 6-237)
6. **Geography** (Units 1-6, Pages 6-237)
7. **History** (Units 1-9, Pages 10-219)
8. **Information Technology** (Units 1-6, Pages 6-251)
9. **Citizenship** (Units 1-8, Pages 6-173)
10. **Physical Education** (Units 1-5, Pages 6-167)

## Omitted / Missing Subjects:
- **Physics**: **NOT INCLUDED**. The raw PDF database `textbooks.db` does not contain a Grade 9 Physics textbook. To prevent hallucination or fake citations, no Physics folder was generated for Grade 9.
